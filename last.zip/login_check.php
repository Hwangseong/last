<?php

session_start();
$conn = mysqli_connect('106.10.40.199', 'th', '2098', 'smart_care');

$email=$_POST['email'];
$pwd=$_POST['pwd'];
//$pwd= md5($pwd = $_POST['pwd']);


$sql="SELECT * FROM USER WHERE ID='{$email}' AND PW='{$pwd}'";
	mysqli_set_charset($conn,"utf8");
$res=$conn->query($sql);

	$row = $res->fetch_array(MYSQLI_ASSOC);
	
	if($row != null) {
		$_SESSION['ses_username'] = $row['NAME'];
		$_SESSION['user_logged'] = 1;
		$_SESSION['user_number'] = $row['U_NO'];
		
		$sql = 'select ME.M_type from MESSAGE_list ML, MESSAGE ME where ML.U_NO = '.$_SESSION['user_number'].' AND ME.M_no = ML.M_no order by ME.M_no asc';
		$result = $conn->query($sql);
		
		if($result == 1) {
			echo("<script type='text/javascript'>alert('비상 메세지가 있습니다!!')</script>");
		}
		echo("<script>location.href='./message.php';</script>");
	}

	else {
		echo("<script type='text/javascript'>alert('로그인 실패! 아이디와 비밀번호가 일치하지 않습니다.')</script>");
		echo("<script>location.href='./login.php';</script>");

	}
?>
