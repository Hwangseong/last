<?php
 header("Content-Type: text/html; charset=utf8");
 
$conn = mysqli_connect('106.10.40.199', 'th', '2098', 'smart_care');

//mysqli_query("set session character_set_connection=utf8;");
//mysqli_query("set session character_set_results=utf8;");
//mysqli_query("set session character_set_client=utf8;");



$email=$_POST['email'];
$password=$_POST['pwd'];
$password2=$_POST['pwd2'];
$name=$_POST['name'];
$phone=$_POST['phone'];
$sex=$_POST['sex'];
$birth=$_POST['birth'];

  $sql = "SELECT * FROM USER WHERE ID = '{$email}'";
  $res = $conn->query($sql);
  
//  if($res->num_rows >= 1){
//	echo("<script type='text/javascript'>alert('이미 존재하는 Email입니다.')</script>");
//	echo("<script>location.href='./register.php';</script>");
//    exit;
//    }
//	
//  if($password !== $password2){
//	echo("<script type='text/javascript'>alert('비밀번호가 일치하지 않습니다.')</script>");
//	echo("<script>location.href='./register.php';</script>");
//        exit;
//    }else{
//        //비밀번호를 암호화 처리.
//        $password = md5($password);
//    }
	
$sql  = "
    INSERT INTO USER (
        ID,
        PW,
        NAME,
		SEX,
		TEL,
		BIRTH
    ) VALUES (
        '{$email}',
        '{$password}',
		'{$name}',
		'{$sex}',
		'{$phone}',
		'{$birth}'
    )";

	mysqli_set_charset($conn,"utf8");
	$result = mysqli_query($conn, $sql);
	echo("<script type='text/javascript'>alert('회원가입 완료!')</script>");
	echo("<script>location.href='./login.php';</script>");
	
	if($result === false){
    echo mysqli_error($conn);
}
?>
