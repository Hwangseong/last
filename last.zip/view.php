<?php

	session_start();
include('connect.php');

$M_no = $_GET['M_no'];


$sql = 'select M_title,M_content,M_date from MESSAGE where M_no =  '.$M_no;

$result = $conn->query($sql);

$row = $result->fetch_assoc();

?>


<!DOCTYPE HTML>

<html>
	<head>
		 <title>SMART_CARE</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/jquery.scrollgress.min.js"></script>
		<script src="js/jquery.scrolly.min.js"></script>
		<script src="js/jquery.slidertron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="index.html">Smart Care</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php">홈으로</a></li>
						<?php 
							if($_SESSION['user_logged']==1){
							?>							
								<li><a href="logout.php">로그아웃</a></li>
								
								<li><a href="message.php">메세지 보기</a></li>
								<?php
							}
							else{
								?>
								<li><a href="login.php">로그인</a></li>
								<li><a href="login.php">메세지 보기</a></li>
								<?php
							}
						?>	
					</ul>
				</nav>
			</header>
			
				<section id="content" class="wrapper style1">
					<section>
					<div class="container">
					<h3>메세지 보기</h3>
						<div id="boardView">
							<div id="boardInfo">
							<span id="boardID">제목 : <?php echo $row['M_title']?></span>
							<br/>
							<span id="boardDate">작성일 : <?php echo $row['M_date']?></span>
							</div>
						</div>
						<div id="boardContent">내용 : <?php echo $row['M_content']?></div>
						<br/>
						<div class="btnSet">
							<a href="message.php" class="button">목록</a>
							</div
						</div>
					</section>
				</section>
			
			<footer id="footer">
				<span class="copyright">
					&copy; SMART CARE PROJECT &copy;  강태길, 류황성, 김태형, 이경석
				</span>
			</footer>

	</body>
</html>		
						