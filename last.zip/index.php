<?php
	session_start();
	
?>
<!DOCTYPE HTML>

<html>
	<head> 
	<title>SMART_CARE</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/jquery.scrollgress.min.js"></script>
		<script src="js/jquery.scrolly.min.js"></script>
		<script src="js/jquery.slidertron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header" class="alt skel-layers-fixed">
				<h1><a href="index.php">Smart Care</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php">홈으로</a></li>
						<?php 
							if($_SESSION['user_logged']==1){
							?>							
								<li><a href="logout.php">로그아웃</a></li>
								
								<li><a href="message.php">메세지 보기</a></li>
								<?php
							}
							else{
								?>
								<li><a href="login.php">로그인</a></li>
								<li><a href="login.php">메세지 보기</a></li>
								<?php
							}
						?>	
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner">
				<div class="inner">
					<h2>SMART CARE</h2>
					<?php 
							if($_SESSION['user_logged']==1){
								echo $_SESSION['ses_username'].'님 안녕하세요';
							}
							else{
								?>
								<p>스마트 케어에 접속하신 분들 환영합니다.</p>
								<?php
							}
						?>	
				</div>
			</section>

			
			<footer id="footer">
				<span class="copyright">
					&copy; SMART CARE PROJECT &copy;  강태길, 류황성, 김태형, 이경석
				</span>
			</footer>

	</body>
</html>