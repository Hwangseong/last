<?php
	
	session_start();
	include('connect.php');

	$M_title=$_POST['M_title'];
	$M_content=$_POST['M_content'];
	$date = date('Y-m-d H:i:s');
	
	
	$sql='insert into MESSAGE (M_title,M_content,M_date) values("'.$M_title.'","'.$M_content.'","'.$date.'")';
	$result=$conn->query($sql);
		
	if($result){
		$msg='정상적으로 글이 등록되었습니다.';
		$M_no=$conn->insert_id;
		$sql='insert into MESSAGE_list (U_NO,M_no) values("'.$_SESSION['user_number'].'","'.$M_no.'")';
		$conn->query($sql);
		
		$replaceURL='view.php?M_no='.$M_no;
	}else{
		$msg="글을 등록하지 못했습니다.";
	
?>
		<script>
			alert("<?php echo $msg?>");
			history.back();
		</script>
<?php
	}
	
	
	
?>

<script>
	alert("<?php echo $msg?>");
	location.replace("<?php echo $replaceURL?>");
</script>