<?php

	session_start();
     
    unset($_SESSION['ses_username']);
 
	unset($_SESSION['user_logged']);
    if($_SESSION['ses_username'] == null){
		echo("<script type='text/javascript'>alert('로그아웃이 정상적으로 되었습니다.')</script>");
		echo("<script>location.href='./index.php';</script>");
	
    }
?>