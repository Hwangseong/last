<?php

	header("Content-Type: text/html;charset=UTF-8");
	$conn = mysqli_connect("106.10.40.199", "gs", "2028", "smart_care");
	
	mysqli_set_charset($conn,"utf8");
?>