/* Magic Mirror Config Sample
 *
 * By Michael Teeuw http://michaelteeuw.nl
 * MIT Licensed.
 *
 * For more information how you can configurate this file
 * See https://github.com/MichMich/MagicMirror#configuration
 *
 */

var config = {
	address: "localhost", // Address to listen on, can be:
	                      // - "localhost", "127.0.0.1", "::1" to listen on loopback interface
	                      // - another specific IPv4/6 to listen on a specific interface
	                      // - "", "0.0.0.0", "::" to listen on any interface
	                      // Default, when address config is left out, is "localhost"
	port: 8080,
	ipWhitelist: ["127.0.0.1", "::ffff:127.0.0.1", "::1"], // Set [] to allow all IP addresses
	                                                       // or add a specific IPv4 of 192.168.1.5 :
	                                                       // ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.1.5"],
	                                                       // or IPv4 range of 192.168.3.0 --> 192.168.3.15 use CIDR format :
	                                                       // ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.3.0/28"],

	language: "en",
	timeFormat: 24,
	units: "metric",

	modules: [
		{
			module: "alert",
		},
		{
			module: "updatenotification",
			position: "top_bar"
		},
		{
			module: "clock",
			position: "top_left",
					config: {
						timezone: "Asia/Seoul"
						}
		},
		{
			module: "calendar",
			header: "calendar",
			position: "top_left",
			config: {
				calendars: [
					{
						symbol: "calendar-check",
						url: "https://calendar.google.com/calendar/ical/fbghkdtjd%40gmail.com/private-8415fa877b6a162c8ad4e7ef5e6cdef4/basic.ics"
					}
				]
			}
		},
		{
			module: "compliments",
			position: "lower_third",
			config: {
				 anytime: ["Hs's Mirror"]
				}
		},
		{
			module: "currentweather",
			position: "top_right",
			config: {
				location: "Cheongju, KR",
				locationID: "1845604",  //ID from http://bulk.openweathermap.org/sample/; unzip the gz file and find your city
				appid: "0f3b2357119e89c21fc79a570c76a731"
			}
		},
		{
			module: "weatherforecast",
			position: "top_right",
			header: "Weather Forecast",
			config: {
				location: "Cheongju, KR",
				locationID: "1845604",  //ID from https://openweathermap.org/city
				appid: "0f3b2357119e89c21fc79a570c76a731"
			}
		},
		{
			module: 'MMM-MysqlQuery',
			position: "top_right",
			config: {
				connection: {
				host: "106.10.40.199",
				port: 3306,
				user: "hs",
				password: "4178",
                           	database: "smart_care"
			},
			query: `select ME.M_title, ME.M_content, ME.M_date, ME.M_no
                        	from MESSAGE_list ML, MESSAGE ME
				where ML.U_NO = 9 AND ME.M_no = ML.M_no
                        	order by ME.M_no DESC
                        	limit 3`,
				intervalSeconds: 15 * 60,
			emptyMessage: "No Message",
			columns: [
				{ name: "M_no", title: "number",cssClass: "left"},
				{ name: "M_title", title: "title",cssClass: "right"},
				{ name: "M_content", title: "content",cssClass: "right"},
				{ name: "M_date", title: "date",cssClass: "right", dataFormat: "date", dataLocale: "kr"}
				]
		}
		},
		{
			module: "newsfeed",
			position: "bottom_bar",
			config: {
				feeds: [
					{
						title: "Jtbc News",
						url: 'http://fs.jtbc.joins.com/RSS/newsflash.xml'
					}
				],
				showSourceTitle: true,
				showPublishDate: true
			}
		},
		{
			module: "MMM-AirQuality",
			position: "top_left",
			config: {
				location: 'cheongju'
			}
		},
		{
			module: "MMM-NotificationTrigger",
			config:
			{
				useWebhook: true,
				triggers:
				[
				{
					trigger: "ASSISTANT_ACTION",
					triggerSenderFilter: function (sender)
					{
						if (sender.name == "MMM-AssistantMk2")
						{
							return true;
						}
						else
						{
							return false;
						}
					},
					triggerPayloadFilter: function (payload)
					{
						return true;
					},
					fires: [{
						fire: "SHOW_ALERT",
						payload: function (payload)
						{
							return {
								type: "notification",
								title: payload[0].execution[0].type,
								message: payload[0].execution[0].command
							};
						},
					}, ],
				},
				{
					trigger: "ASSISTANT_HOOK",
					fires: [{
					fire: "SHOW_ALERT",
					payload: function (payload)
					{
						return {
							title: "HOOK",
							message: "Are you saying " + payload.hook + "?",
							timer: 5000
						};
					},
					}, ],
				},
				{
					trigger: "HOTWORD_DETECTED",
					fires: [{
						fire: "HOTWORD_PAUSE"
						},
						{
						fire: "ASSISTANT_ACTIVATE",
						payload: function (payload) {
							return {
							"profile": payload.hotword
							};
						},
						delay: 200
						},
					]
				},
				{
					trigger: "ASSISTANT_DEACTIVATED",
					fires: [{
						fire: "HOTWORD_RESUME"
					}]
				},
				]
			}
		},
		{
			module: "MMM-Hotword",
			config:
			{
				snowboy: [{
					hotwords: "smartmirror",
					file: "resources/models/smart_mirror.umdl",
					sensitivity: '6.0',
				}]
			}
		},
		{
			module: "MMM-AssistantMk2",
			position: "top_center",
			config:
			{
				useScreen: true,
				deviceLocation:{
					coordinates: {
					latitude: 37.57,
					longitude: 126.98
				},
			},
			profiles: {
				"default": {
					lang: "ko-KR"
				},
			}
		}
		},
	]

};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") {module.exports = config;}
