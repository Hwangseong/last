<?php
	session_start();
	include('connect.php');
	$sql = 'update MESSAGE, MESSAGE_list set MESSAGE.M_type = 0 where MESSAGE.M_no = MESSAGE_list.M_no and MESSAGE_list.U_NO = '.$_SESSION['user_number'].'';
	$result=$conn->query($sql);
	
?>
<!DOCTYPE HTML>

<html>
	<head>
		 <title>SMART_CARE</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/jquery.scrollgress.min.js"></script>
		<script src="js/jquery.scrolly.min.js"></script>
		<script src="js/jquery.slidertron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="index.php">Smart Care</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php">홈으로</a></li>
						<?php 
							if($_SESSION['user_logged']==1){
							?>							
								<li><a href="logout.php">로그아웃</a></li>

								<?php
							}
							else{
								?>
								<li><a href="login.php">로그인</a></li>
								<?php
							}
						?>	
							<li><a href="message.php">메세지 보기</a></li>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="content" class="wrapper style1">
				<section>
					<div class="container">
						<h3>메세지</h3>
					<style>
						tbody>tr {
						counter-increment: aaa;
						}
						tbody>tr>td:first-child:before {
						content: counter(aaa) " ";
						}
					</style>
						<table class="alt">
							<thead>
								<tr>
									<th>No.</th>
									<th>제목</th>
									<th>내용</th>
									<th>날짜</th>
								</tr>
							</thead>
							<tbody>
								<?php      
									$sql = 'select M_title,M_content,M_date,M_type from MESSAGE_list ML, MESSAGE ME where ML.U_NO = '.$_SESSION['user_number'].' AND ME.M_no = ML.M_no order by ME.M_no asc';
									$result = $conn->query($sql);
									while($row = $result->fetch_assoc()){

								?>
								<tr>
									<td width = "50" class="no"><?php echo $row['M_no']?></td>
									<td width = "100" class="title"><?php echo $row['M_title']?></td>
									<td width = "250" class="content"><?php echo $row['M_content']?></td>
									<td width = "70" class="date"><?php echo $row['M_date']?></td>
								</tr>
								<?php
									}
								?>
							</tbody>
						</table>
						<hr/>
						<div class="btnSet">
							<a href="write.php" class="button" style="float:right;">메세지 보내기</a>
							<br>
						</div>
					</div>
				</section>
			</section>

			
			
		<footer id="footer">
				<span class="copyright">
					&copy; SMART CARE PROJECT &copy;  강태길, 류황성, 김태형, 이경석
				</span>
			</footer>

	</body>
</html>